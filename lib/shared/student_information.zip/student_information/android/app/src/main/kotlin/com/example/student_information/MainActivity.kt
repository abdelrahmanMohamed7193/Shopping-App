package com.example.student_information

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
