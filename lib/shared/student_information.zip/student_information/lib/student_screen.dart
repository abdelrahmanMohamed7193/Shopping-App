import 'package:flutter/material.dart';

class StudentScreen extends StatefulWidget {
  StudentScreen({Key? key}) : super(key: key);

  @override
  State<StudentScreen> createState() => _StudentScreenState();
}

class _StudentScreenState extends State<StudentScreen> {
  TextEditingController emailController = TextEditingController();

  TextEditingController passController = TextEditingController();

 bool? isFirstChoosen =false ;
 bool? isSecondChoosen =false ;

  Widget myTextField({
    required TextEditingController controller,
    required TextInputType type,
    required String validateText,
    required IconData prefixIcon,
    Function? onTap,
    // required Function validator ,
    Function? onChanged,
    Function? onSubmit,
    required String label,
    IconData? suffixIcon,
    Function? SuffixPressed,
    bool readonly = false,
    bool isPassword = false,
  }) =>
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          onFieldSubmitted: (s) {
            onSubmit!(s);
          },
          onTap: () {
            onTap!();
          },
          decoration: InputDecoration(
            label: Text(label),
            prefixIcon: Icon(prefixIcon),
            suffixIcon: IconButton(
              onPressed: () {
                SuffixPressed!();
              },
              icon: Icon(suffixIcon),
            ),
            border: const OutlineInputBorder(),
          ),
          readOnly: readonly,
          validator: (value) {
            if (value!.isEmpty) {
              return (validateText);
            }
          },
          obscureText: isPassword,
          onChanged: (value) {
            onChanged!(value);
          },
          controller: controller,
          keyboardType: type,
        ),
      );

  Widget myButton({
    required String text,
    required Function onTap,
  }) =>
      GestureDetector(
        onTap: () {
          onTap();
        },
        child: Center(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.blueAccent,
              borderRadius: BorderRadius.circular(20.0),
            ),
            width: 90,
            height: 60.0,
            child: Center(
              child: Text(
                text,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student information'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(

          children: [

            myTextField(
              controller: emailController,
              type: TextInputType.emailAddress,
              validateText: 'this field is required',
              prefixIcon: Icons.face,
              label: 'email',
            ),

            myTextField(
              controller: passController,
              type: TextInputType.visiblePassword,
              validateText: 'this field is required',
              prefixIcon: Icons.password,
              label: 'password',
              isPassword: true ,

            ),

           Padding(
             padding: const EdgeInsets.all(8.0),
             child: Row(
               children: [
                 Text(' do you have a car ?' ,
                 style: TextStyle(fontSize: 17.0 ,fontWeight:FontWeight.bold),
                 ) ,
                 SizedBox(width: 30.0,) ,

                 GestureDetector(
                   onTap: (){
                     isFirstChoosen= true ;
                     isSecondChoosen=false ;
                     setState(() {

                     });
                   },
                   child: Container(
                     child: Text('yes' ,textAlign: TextAlign.center),
                     height: 40,
                     width:40,
                     decoration: BoxDecoration(

                       color: isFirstChoosen! ? Colors.blueAccent :Colors.white ,
                       shape: BoxShape.circle ,
                       border: Border.all(color: Colors.black) ,
                     ),

                   ),
                 ) ,
                 SizedBox(width: 30.0,) ,

                 GestureDetector(
                   onTap: (){
                     isSecondChoosen=true ;
                     isFirstChoosen=false;
                     setState(() {

                     });
                   },
                   child: Container(
                     child: Text('no' ,textAlign: TextAlign.center),
                     height: 40,
                     width: 40,
                     decoration: BoxDecoration(
                       color: isSecondChoosen! ? Colors.blueAccent :Colors.white ,
                       shape: BoxShape.circle ,
                       border: Border.all(color: Colors.black ,


                       ) ,
                     ),

                   ),
                 ) ,



               ],
             ),
           )




           // myButton(text: text, onTap: onTap)

          ],
        ),
      ),
    );
  }
}
